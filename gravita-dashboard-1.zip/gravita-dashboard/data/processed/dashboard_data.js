window.GRAVITA_DATA = [
 {
  "year": 2018,
  "hs": "251611",
  "level": 6,
  "th": "หินแกรนิตดิบหรือตัดหยาบ",
  "en": "Granite, crude or roughly trimmed",
  "kusd": 28.26,
  "kg": 29619.0
 },
 {
  "year": 2021,
  "hs": "251611",
  "level": 6,
  "th": "หินแกรนิตดิบหรือตัดหยาบ",
  "en": "Granite, crude or roughly trimmed",
  "kusd": 0.2,
  "kg": 1557.0
 },
 {
  "year": 2023,
  "hs": "251612",
  "level": 6,
  "th": "หินแกรนิตตัดเป็นก้อน/แผ่นสี่เหลี่ยม",
  "en": "Granite, merely cut into a square or rectangular shape",
  "kusd": 548.65,
  "kg": null
 },
 {
  "year": 2023,
  "hs": "251511",
  "level": 6,
  "th": "หินอ่อนและทราเวอร์ทีนดิบหรือตัดหยาบ",
  "en": "Marble and travertine, crude or roughly trimmed",
  "kusd": 1.9,
  "kg": 32079.0
 },
 {
  "year": 2023,
  "hs": "251512",
  "level": 6,
  "th": "หินอ่อนและทราเวอร์ทีนตัดเป็นก้อน/แผ่นสี่เหลี่ยม",
  "en": "Marble and travertine, merely cut into a square or rectangular shape",
  "kusd": 28.96,
  "kg": 9048.0
 },
 {
  "year": 2022,
  "hs": "2516",
  "level": 4,
  "th": "กลุ่มหินแกรนิต หินก่อสร้าง (รวมกลุ่ม 2516)",
  "en": "Granite, porphyry, basalt, sandstone and other building stone (group total)",
  "kusd": 620.0,
  "kg": null
 },
 {
  "year": 2023,
  "hs": "2516",
  "level": 4,
  "th": "กลุ่มหินแกรนิต หินก่อสร้าง (รวมกลุ่ม 2516)",
  "en": "Granite, porphyry, basalt, sandstone and other building stone (group total)",
  "kusd": 605.0,
  "kg": null
 }
];
