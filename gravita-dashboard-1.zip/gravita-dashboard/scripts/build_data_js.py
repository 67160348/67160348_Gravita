"""Convert data/processed/export_hs_thailand.csv into data/processed/dashboard_data.js
so index.html works when opened directly (file://) without a web server."""
import csv, json, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "data/processed/export_hs_thailand.csv"
dst = root / "data/processed/dashboard_data.js"

rows = []
with src.open(encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append({
            "year": int(r["year"]),
            "hs": r["hs_code"],
            "level": int(r["hs_level"]),
            "th": r["product_th"],
            "en": r["product_en"],
            "kusd": float(r["value_kusd"]),
            "kg": float(r["quantity_kg"]) if r["quantity_kg"] else None,
        })

dst.write_text("window.GRAVITA_DATA = " + json.dumps(rows, ensure_ascii=False, indent=1) + ";\n", encoding="utf-8")
print(f"wrote {len(rows)} rows -> {dst}")
